*********************************************************************************************
              SRunner on Windows XP: Version 1.2 README 7/12/2005
*********************************************************************************************

CONTENTS
--------
A. DESCRIPTION
B. INCLUDED
C. PORTING
D. SUPPORT
E. REVISION


A. DESCRIPTION
--------------
SRunner is a standalone Windows based software driver that allows user to program 
Altera Serial Configuration Devices (EPCS1, EPCS4, EPCS16 and EPCS64), using Byteblaster II download cable. 
SRunner is developed and tested in the Windows XP platform. 
SRunner software can be easily modified and ported to other system for programming the EPCS. 
The input file to SRunner is Raw Programming Data (RPD) file, which is generated 
by Quartus II version 2.2 SP2 and above. 
SRunner reads the RPD file and programs the data to the EPCS via serial interface. 


B. INCLUDED
-----------
The following table provides the directory structure of the files in this release:

Directory	Filename	Description
---------	--------	-----------
\bin		srunner.exe	SRunner Software Driver on Windows XP Platform
				

\source		main.c		Contain the main( ) function to create the user 
				interface with the software driver to execute the read
 				and program action.This file is platform dependent.  

\source		user.h		List of error code

\source		as.c		Contain active serial algorithm to interface with EPCS.
		as.h		This file includes function to erase, program, read, 
				verify data, read silicon ID, etc.
				The header file contains Active Serial instruction set.

\source		fs.c		File system module to open, close, create and read file
		fs.h		This file is platform dependent.

\source 	bb.c		Byteblaster II and Byteblaster MV driver to drive the 
		bb.h		signal to the programming cable. 
				(Byteblaster MV do not support EPCS programming) 
				This file is platform dependent.

		
C. PORTING
----------
To port the source code to other platforms or embedded systems, User must implement I/O control 
routines in the existing to replace the current fs module (fs.c and fs.h) and bb module (bb.c and bb.h files). 

The platform dependent source files, which are main.c, fs.c, fs.h, bb.c and bb.h must be 
customized to work with user system as different platforms have different ways of interfacing with I/Os and 
handling data in the memory.  

The source files as.c and as.h does not required to much customization as they are platform independent.


D. SUPPORT
----------
For additional support, please refer to www.altera.com.


E. REVISION
-----------
09/30/2004	Version 1.0	
12/07/2005	Version 1.1	Included EPCS64 support
06/11/2008	Version 1.2	Included EPCS128 support
